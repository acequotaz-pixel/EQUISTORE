import { useState, useEffect, useRef } from "react";

// ─── DESIGN TOKENS ───────────────────────────────────────────────────────────
const T = {
  navy:    "#0A0F1E",
  navyMid: "#141929",
  navyLt:  "#1E2640",
  cobalt:  "#2563EB",
  cobaltLt:"#3B82F6",
  gold:    "#F59E0B",
  goldLt:  "#FCD34D",
  plat:    "#E8EBF0",
  platDk:  "#B8BDC8",
  white:   "#FFFFFF",
  red:     "#EF4444",
  green:   "#10B981",
};

// ─── DATA ────────────────────────────────────────────────────────────────────
const CATEGORIES = [
  { id: "all",        label: "All Products", icon: "◈" },
  { id: "electronics",label: "Electronics",  icon: "⚡" },
  { id: "fashion",    label: "Fashion",      icon: "✦" },
  { id: "home",       label: "Home & Living",icon: "⌂" },
  { id: "beauty",     label: "Beauty",       icon: "✿" },
];

const PRODUCTS = [
  { id:1,  name:"Pro Wireless Headphones",  cat:"electronics", price:249,  oldPrice:319,  rating:4.8, reviews:2341, badge:"Best Seller", color:"#1E2640", img:"🎧", desc:"Studio-grade audio with 40hr battery, active noise cancellation, and premium leather cushions. Bluetooth 5.3 with multipoint connection." },
  { id:2,  name:"Ultra Slim 4K Monitor",    cat:"electronics", price:599,  oldPrice:749,  rating:4.7, reviews:876,  badge:"New",         color:"#162032", img:"🖥️", desc:"27-inch IPS panel with 144Hz refresh, HDR600, and USB-C 65W charging. Perfect for creative work and gaming." },
  { id:3,  name:"Smart Fitness Watch",      cat:"electronics", price:189,  oldPrice:229,  rating:4.6, reviews:5432, badge:"Top Rated",   color:"#1A2438", img:"⌚", desc:"Advanced health monitoring: ECG, blood oxygen, sleep tracking, and 14-day battery. Water-resistant to 50m." },
  { id:4,  name:"Mechanical Keyboard",      cat:"electronics", price:129,  oldPrice:159,  rating:4.9, reviews:1209, badge:"",            color:"#1B1F2E", img:"⌨️", desc:"TKL layout with Cherry MX switches, per-key RGB lighting, and aluminum chassis. N-key rollover for gaming." },
  { id:5,  name:"Oversized Linen Blazer",   cat:"fashion",     price:189,  oldPrice:260,  rating:4.5, reviews:643,  badge:"Trending",    color:"#1E1A2E", img:"🧥", desc:"Relaxed-fit linen blazer in stone white. Unstructured shoulders, notch lapel. Available in S–XXL. Machine washable." },
  { id:6,  name:"Premium Leather Tote",     cat:"fashion",     price:295,  oldPrice:380,  rating:4.8, reviews:421,  badge:"",            color:"#241A1A", img:"👜", desc:"Full-grain Italian leather with gold-tone hardware. Padded laptop sleeve, magnetic closure, detachable strap." },
  { id:7,  name:"Minimalist Sneakers",      cat:"fashion",     price:145,  oldPrice:180,  rating:4.6, reviews:3876, badge:"Fan Favorite",color:"#1A1E2A", img:"👟", desc:"Vulcanized sole, premium canvas upper, ergonomic footbed. Collab with Copenhagen Studio. Unisex sizing." },
  { id:8,  name:"Silk Slip Dress",          cat:"fashion",     price:220,  oldPrice:295,  rating:4.7, reviews:289,  badge:"New",         color:"#2A1A2A", img:"👗", desc:"100% mulberry silk, bias-cut silhouette with adjustable straps. Available in champagne, midnight, and sage." },
  { id:9,  name:"Ceramic Pour-Over Set",    cat:"home",        price:89,   oldPrice:115,  rating:4.9, reviews:2108, badge:"Staff Pick",  color:"#1A1E18", img:"☕", desc:"Hand-thrown stoneware dripper and carafe. Comes with 50 bleach-free filters. Brews 1–4 cups. Dishwasher safe." },
  { id:10, name:"Modular Shelf System",     cat:"home",        price:349,  oldPrice:430,  rating:4.6, reviews:532,  badge:"",            color:"#1E1A14", img:"🗄️", desc:"Solid oak uprights with steel connectors. 6 shelves included, infinitely configurable. Weight-rated 40kg per shelf." },
  { id:11, name:"Linen Duvet Cover",        cat:"home",        price:149,  oldPrice:195,  rating:4.8, reviews:1874, badge:"Eco",         color:"#181E1A", img:"🛏️", desc:"Stonewashed Belgian linen, OEKO-TEX certified. Button closure, internal corner ties. King & queen sizes available." },
  { id:12, name:"Aromatherapy Diffuser",    cat:"home",        price:65,   oldPrice:85,   rating:4.5, reviews:987,  badge:"",            color:"#1A1820", img:"💨", desc:"Ultrasonic diffuser, 500ml capacity, 12hr runtime. Includes 4 essential oil blends. Whisper quiet operation." },
  { id:13, name:"Vitamin C Serum",          cat:"beauty",      price:58,   oldPrice:79,   rating:4.8, reviews:6541, badge:"Best Seller", color:"#201A14", img:"✨", desc:"15% L-ascorbic acid with ferulic acid and vitamin E. Brightens, firms, and protects against UV damage. 30ml." },
  { id:14, name:"Squalane Face Oil",        cat:"beauty",      price:42,   oldPrice:55,   rating:4.7, reviews:3287, badge:"Clean",       color:"#1A1E20", img:"💧", desc:"100% plant-derived squalane. Non-comedogenic, suitable for all skin types. Lightweight and absorbs instantly." },
  { id:15, name:"Refillable Perfume",       cat:"beauty",      price:135,  oldPrice:175,  rating:4.9, reviews:1043, badge:"Luxury",      color:"#1E1822", img:"🌹", desc:"Eau de parfum in refillable glass atomiser. Top: bergamot & lemon. Heart: rose & iris. Base: sandalwood & musk." },
  { id:16, name:"SPF 50 Tinted Moisturiser",cat:"beauty",      price:38,   oldPrice:50,   rating:4.6, reviews:4210, badge:"New",         color:"#201C14", img:"🧴", desc:"Mineral SPF50 with sheer tint, hydrating hyaluronic acid, and antioxidant green tea extract. 6 shades." },
];

const HERO_STATS = [
  { val:"50K+", label:"Products" },
  { val:"2M+",  label:"Customers" },
  { val:"4.9★", label:"Avg Rating" },
  { val:"98%",  label:"Satisfaction" },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const discount = (p, o) => Math.round(((o - p) / o) * 100);
const fmt = (n) => `$${n.toLocaleString()}`;

// ─── COMPONENTS ──────────────────────────────────────────────────────────────

function StarRating({ rating, size = 14 }) {
  return (
    <span style={{ fontSize: size, letterSpacing: 1 }}>
      {[1,2,3,4,5].map(i => (
        <span key={i} style={{ color: i <= Math.round(rating) ? T.gold : T.navyLt }}>★</span>
      ))}
    </span>
  );
}

function Badge({ text, style }) {
  if (!text) return null;
  const colors = {
    "Best Seller": T.gold,
    "New": T.cobalt,
    "Top Rated": T.green,
    "Fan Favorite": "#A855F7",
    "Staff Pick": T.cobalt,
    "Trending": "#EC4899",
    "Eco": T.green,
    "Clean": T.green,
    "Luxury": T.gold,
  };
  return (
    <span style={{
      background: colors[text] || T.cobalt,
      color: text === T.gold || colors[text] === T.gold ? T.navy : T.white,
      fontSize: 10, fontWeight: 700, padding: "2px 8px",
      borderRadius: 20, letterSpacing: 0.8, textTransform: "uppercase",
      ...style,
    }}>{text}</span>
  );
}

function Notification({ msg, show }) {
  return (
    <div style={{
      position:"fixed", bottom: 24, right: 24, zIndex: 9999,
      background: T.green, color: T.white,
      padding: "12px 20px", borderRadius: 10,
      fontWeight: 600, fontSize: 14,
      boxShadow: "0 8px 30px rgba(16,185,129,0.4)",
      transform: show ? "translateY(0)" : "translateY(100px)",
      opacity: show ? 1 : 0,
      transition: "all 0.35s cubic-bezier(0.34,1.56,0.64,1)",
      pointerEvents: "none",
    }}>✓ {msg}</div>
  );
}

// ─── NAVBAR ──────────────────────────────────────────────────────────────────
function Navbar({ cartCount, onCartOpen, onHome, page, onSearch, searchQ }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);
  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 1000,
      background: scrolled ? `${T.navy}F0` : "transparent",
      backdropFilter: scrolled ? "blur(16px)" : "none",
      borderBottom: scrolled ? `1px solid ${T.navyLt}` : "none",
      transition: "all 0.3s ease",
      padding: "0 5%",
    }}>
      <div style={{
        maxWidth: 1280, margin: "0 auto",
        display: "flex", alignItems: "center", gap: 16,
        height: 68,
      }}>
        {/* Logo */}
        <div onClick={onHome} style={{
          fontWeight: 900, fontSize: 22, letterSpacing: -1,
          color: T.white, cursor: "pointer", flexShrink: 0,
          display: "flex", alignItems: "center", gap: 6,
        }}>
          <span style={{
            background: `linear-gradient(135deg, ${T.cobalt}, ${T.gold})`,
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>NEXUS</span>
          <span style={{ color: T.platDk, fontWeight: 300, fontSize: 12, letterSpacing: 2 }}>STORE</span>
        </div>

        {/* Search */}
        <div style={{ flex: 1, maxWidth: 480, position: "relative" }}>
          <span style={{
            position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)",
            color: T.platDk, fontSize: 16, pointerEvents: "none",
          }}>⌕</span>
          <input
            value={searchQ}
            onChange={e => onSearch(e.target.value)}
            placeholder="Search products, brands..."
            style={{
              width: "100%", background: T.navyLt,
              border: `1px solid ${T.navyMid}`,
              color: T.white, borderRadius: 10,
              padding: "9px 14px 9px 40px", fontSize: 14,
              outline: "none", boxSizing: "border-box",
              transition: "border 0.2s",
            }}
            onFocus={e => e.target.style.borderColor = T.cobalt}
            onBlur={e => e.target.style.borderColor = T.navyMid}
          />
        </div>

        {/* Nav Links */}
        <div style={{ display: "flex", gap: 28, alignItems: "center" }}>
          {["Shop","Deals","Brands"].map(l => (
            <span key={l} style={{
              color: T.platDk, fontSize: 14, fontWeight: 500,
              cursor: "pointer", transition: "color 0.2s",
            }}
            onMouseEnter={e => e.target.style.color = T.white}
            onMouseLeave={e => e.target.style.color = T.platDk}
            >{l}</span>
          ))}
        </div>

        {/* Cart */}
        <button onClick={onCartOpen} style={{
          background: cartCount > 0 ? T.cobalt : T.navyLt,
          border: "none", color: T.white, borderRadius: 10,
          padding: "8px 16px", fontSize: 14, fontWeight: 600,
          cursor: "pointer", display: "flex", alignItems: "center", gap: 8,
          transition: "all 0.2s", flexShrink: 0,
        }}>
          🛒
          {cartCount > 0 && (
            <span style={{
              background: T.gold, color: T.navy,
              borderRadius: "50%", width: 20, height: 20,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 11, fontWeight: 800, flexShrink: 0,
            }}>{cartCount}</span>
          )}
        </button>
      </div>
    </nav>
  );
}

// ─── HERO SECTION ────────────────────────────────────────────────────────────
function Hero({ onShop }) {
  const [active, setActive] = useState(0);
  const slides = [
    { title: "Next-Gen Tech,", accent: "Delivered Fast.", sub: "Curated electronics from the world's top brands.", cat: "electronics", emoji: "⚡" },
    { title: "Dress Like You", accent: "Mean It.", sub: "Seasonal drops from independent and global labels.", cat: "fashion", emoji: "✦" },
    { title: "Your Home,", accent: "Elevated.", sub: "Considered objects for living with intention.", cat: "home", emoji: "⌂" },
  ];
  useEffect(() => {
    const t = setInterval(() => setActive(a => (a + 1) % slides.length), 4500);
    return () => clearInterval(t);
  }, []);
  const s = slides[active];
  return (
    <section style={{
      minHeight: "100vh",
      background: `radial-gradient(ellipse at 30% 50%, ${T.navyMid} 0%, ${T.navy} 70%)`,
      display: "flex", flexDirection: "column",
      justifyContent: "center", alignItems: "center",
      textAlign: "center", padding: "100px 5% 60px",
      position: "relative", overflow: "hidden",
    }}>
      {/* Background grid */}
      <div style={{
        position: "absolute", inset: 0, opacity: 0.04,
        backgroundImage: `linear-gradient(${T.white} 1px, transparent 1px), linear-gradient(90deg, ${T.white} 1px, transparent 1px)`,
        backgroundSize: "60px 60px",
      }} />
      {/* Glow */}
      <div style={{
        position: "absolute", width: 600, height: 600,
        background: `radial-gradient(circle, ${T.cobalt}22 0%, transparent 70%)`,
        top: "20%", left: "50%", transform: "translateX(-50%)",
        pointerEvents: "none",
      }} />

      <div style={{ position: "relative", maxWidth: 760 }}>
        {/* Slide indicator */}
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 32 }}>
          {slides.map((_, i) => (
            <div key={i} onClick={() => setActive(i)} style={{
              width: i === active ? 28 : 8, height: 8,
              borderRadius: 4, cursor: "pointer",
              background: i === active ? T.cobalt : T.navyLt,
              transition: "all 0.3s",
            }} />
          ))}
        </div>

        <div key={active} style={{ animation: "fadeUp 0.6s ease" }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>{s.emoji}</div>
          <h1 style={{
            fontSize: "clamp(40px, 7vw, 80px)", fontWeight: 900,
            lineHeight: 1.05, margin: "0 0 8px",
            color: T.white, letterSpacing: -2,
          }}>{s.title}</h1>
          <h1 style={{
            fontSize: "clamp(40px, 7vw, 80px)", fontWeight: 900,
            lineHeight: 1.05, margin: "0 0 24px",
            background: `linear-gradient(135deg, ${T.cobaltLt}, ${T.gold})`,
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            letterSpacing: -2,
          }}>{s.accent}</h1>
          <p style={{ color: T.platDk, fontSize: 18, marginBottom: 40, lineHeight: 1.6 }}>{s.sub}</p>
        </div>

        <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
          <button onClick={() => onShop(s.cat)} style={{
            background: T.cobalt, color: T.white,
            border: "none", borderRadius: 12,
            padding: "15px 36px", fontSize: 16, fontWeight: 700,
            cursor: "pointer", transition: "all 0.2s",
            boxShadow: `0 8px 32px ${T.cobalt}55`,
          }}
          onMouseEnter={e => { e.target.style.background = T.cobaltLt; e.target.style.transform = "translateY(-2px)"; }}
          onMouseLeave={e => { e.target.style.background = T.cobalt; e.target.style.transform = "none"; }}
          >Shop Now →</button>
          <button onClick={() => onShop("all")} style={{
            background: "transparent", color: T.plat,
            border: `1.5px solid ${T.navyLt}`, borderRadius: 12,
            padding: "15px 36px", fontSize: 16, fontWeight: 600,
            cursor: "pointer", transition: "all 0.2s",
          }}
          onMouseEnter={e => { e.target.style.borderColor = T.platDk; }}
          onMouseLeave={e => { e.target.style.borderColor = T.navyLt; }}
          >Browse All</button>
        </div>

        {/* Stats */}
        <div style={{
          display: "flex", gap: 40, justifyContent: "center",
          marginTop: 64, flexWrap: "wrap",
        }}>
          {HERO_STATS.map(s => (
            <div key={s.label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 28, fontWeight: 900, color: T.white, letterSpacing: -1 }}>{s.val}</div>
              <div style={{ fontSize: 13, color: T.platDk, marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll hint */}
      <div style={{
        position: "absolute", bottom: 28, left: "50%", transform: "translateX(-50%)",
        color: T.platDk, fontSize: 12, display: "flex", flexDirection: "column",
        alignItems: "center", gap: 6, animation: "bounce 2s infinite",
      }}>
        <span>Scroll</span>
        <span>↓</span>
      </div>
    </section>
  );
}

// ─── PRODUCT CARD ────────────────────────────────────────────────────────────
function ProductCard({ product, onAdd, onView }) {
  const [hovered, setHovered] = useState(false);
  const [added, setAdded] = useState(false);

  const handleAdd = (e) => {
    e.stopPropagation();
    onAdd(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div
      onClick={() => onView(product)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? T.navyMid : T.navyLt,
        borderRadius: 16, overflow: "hidden", cursor: "pointer",
        border: `1px solid ${hovered ? T.cobalt + "55" : T.navyLt}`,
        transition: "all 0.25s ease",
        transform: hovered ? "translateY(-4px)" : "none",
        boxShadow: hovered ? `0 16px 48px ${T.navy}99` : "none",
        display: "flex", flexDirection: "column",
      }}
    >
      {/* Image area */}
      <div style={{
        background: `linear-gradient(135deg, ${product.color} 0%, ${T.navy} 100%)`,
        height: 200, display: "flex", alignItems: "center",
        justifyContent: "center", fontSize: 72, position: "relative",
        overflow: "hidden",
      }}>
        <span style={{ transition: "transform 0.3s", transform: hovered ? "scale(1.1)" : "scale(1)" }}>
          {product.img}
        </span>
        {product.badge && (
          <div style={{ position: "absolute", top: 12, left: 12 }}>
            <Badge text={product.badge} />
          </div>
        )}
        <div style={{
          position: "absolute", top: 12, right: 12,
          background: T.red, color: T.white, borderRadius: 6,
          fontSize: 11, fontWeight: 700, padding: "2px 7px",
        }}>-{discount(product.price, product.oldPrice)}%</div>
      </div>

      {/* Info */}
      <div style={{ padding: "16px", flex: 1, display: "flex", flexDirection: "column", gap: 8 }}>
        <div style={{ color: T.platDk, fontSize: 11, textTransform: "uppercase", letterSpacing: 1 }}>
          {CATEGORIES.find(c => c.id === product.cat)?.label}
        </div>
        <div style={{ color: T.white, fontWeight: 700, fontSize: 15, lineHeight: 1.3 }}>
          {product.name}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <StarRating rating={product.rating} />
          <span style={{ color: T.platDk, fontSize: 12 }}>({product.reviews.toLocaleString()})</span>
        </div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: "auto" }}>
          <span style={{ color: T.white, fontWeight: 800, fontSize: 20 }}>{fmt(product.price)}</span>
          <span style={{ color: T.platDk, fontSize: 13, textDecoration: "line-through" }}>{fmt(product.oldPrice)}</span>
        </div>
        <button
          onClick={handleAdd}
          style={{
            width: "100%", padding: "10px",
            background: added ? T.green : (hovered ? T.cobalt : T.navyMid),
            color: T.white, border: `1px solid ${hovered ? T.cobalt : T.navyLt}`,
            borderRadius: 10, fontWeight: 700, fontSize: 14,
            cursor: "pointer", transition: "all 0.2s",
            marginTop: 4,
          }}
        >{added ? "✓ Added!" : "Add to Cart"}</button>
      </div>
    </div>
  );
}

// ─── SHOP PAGE ───────────────────────────────────────────────────────────────
function ShopPage({ initCat, onAdd, onView, searchQ }) {
  const [cat, setCat] = useState(initCat || "all");
  const [sort, setSort] = useState("default");

  useEffect(() => { if (initCat) setCat(initCat); }, [initCat]);

  let products = cat === "all" ? PRODUCTS : PRODUCTS.filter(p => p.cat === cat);
  if (searchQ) {
    const q = searchQ.toLowerCase();
    products = products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.desc.toLowerCase().includes(q) ||
      p.cat.toLowerCase().includes(q)
    );
  }
  if (sort === "price-asc")  products = [...products].sort((a,b) => a.price - b.price);
  if (sort === "price-desc") products = [...products].sort((a,b) => b.price - a.price);
  if (sort === "rating")     products = [...products].sort((a,b) => b.rating - a.rating);

  return (
    <section style={{ minHeight: "100vh", background: T.navy, padding: "100px 5% 80px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ marginBottom: 40 }}>
          <div style={{ color: T.cobaltLt, fontSize: 13, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>
            — Explore
          </div>
          <h2 style={{ color: T.white, fontSize: "clamp(28px, 4vw, 48px)", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
            {searchQ ? `Results for "${searchQ}"` : "All Products"}
          </h2>
        </div>

        {/* Filters bar */}
        <div style={{
          display: "flex", gap: 10, marginBottom: 32,
          flexWrap: "wrap", alignItems: "center",
        }}>
          {/* Category tabs */}
          <div style={{ display: "flex", gap: 8, flex: 1, flexWrap: "wrap" }}>
            {CATEGORIES.map(c => (
              <button key={c.id} onClick={() => setCat(c.id)} style={{
                padding: "8px 18px", borderRadius: 50,
                background: cat === c.id ? T.cobalt : T.navyLt,
                border: `1px solid ${cat === c.id ? T.cobalt : T.navyLt}`,
                color: cat === c.id ? T.white : T.platDk,
                fontSize: 13, fontWeight: 600, cursor: "pointer",
                transition: "all 0.2s",
              }}>{c.icon} {c.label}</button>
            ))}
          </div>
          {/* Sort */}
          <select value={sort} onChange={e => setSort(e.target.value)} style={{
            background: T.navyLt, border: `1px solid ${T.navyLt}`,
            color: T.platDk, borderRadius: 8, padding: "8px 12px",
            fontSize: 13, cursor: "pointer", outline: "none",
          }}>
            <option value="default">Sort: Default</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>

        {/* Results count */}
        <div style={{ color: T.platDk, fontSize: 13, marginBottom: 24 }}>
          {products.length} product{products.length !== 1 ? "s" : ""} found
        </div>

        {/* Grid */}
        {products.length === 0 ? (
          <div style={{ textAlign: "center", color: T.platDk, padding: "80px 0", fontSize: 18 }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
            No products match your search. Try different keywords.
          </div>
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            gap: 20,
          }}>
            {products.map(p => (
              <ProductCard key={p.id} product={p} onAdd={onAdd} onView={onView} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

// ─── PRODUCT DETAIL ──────────────────────────────────────────────────────────
function ProductDetail({ product, onAdd, onBack }) {
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    for (let i = 0; i < qty; i++) onAdd(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const related = PRODUCTS.filter(p => p.cat === product.cat && p.id !== product.id).slice(0, 3);

  return (
    <div style={{ minHeight: "100vh", background: T.navy, padding: "100px 5% 80px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Back */}
        <button onClick={onBack} style={{
          background: "none", border: "none", color: T.platDk,
          fontSize: 14, cursor: "pointer", marginBottom: 32,
          display: "flex", alignItems: "center", gap: 6, padding: 0,
        }}>← Back to Shop</button>

        {/* Main */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
          {/* Image */}
          <div style={{
            background: `linear-gradient(135deg, ${product.color} 0%, ${T.navy} 100%)`,
            borderRadius: 20, height: 440,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 120, position: "relative",
          }}>
            {product.img}
            {product.badge && (
              <div style={{ position: "absolute", top: 20, left: 20 }}>
                <Badge text={product.badge} style={{ fontSize: 13, padding: "4px 12px" }} />
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            <div style={{ color: T.cobaltLt, fontSize: 12, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>
              {CATEGORIES.find(c => c.id === product.cat)?.label}
            </div>
            <h1 style={{ color: T.white, fontSize: 32, fontWeight: 900, margin: "0 0 16px", lineHeight: 1.2, letterSpacing: -0.5 }}>
              {product.name}
            </h1>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
              <StarRating rating={product.rating} size={18} />
              <span style={{ color: T.platDk, fontSize: 14 }}>{product.rating} ({product.reviews.toLocaleString()} reviews)</span>
            </div>
            <p style={{ color: T.platDk, lineHeight: 1.7, fontSize: 15, marginBottom: 28 }}>{product.desc}</p>

            <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 28 }}>
              <span style={{ color: T.white, fontSize: 38, fontWeight: 900 }}>{fmt(product.price)}</span>
              <span style={{ color: T.platDk, fontSize: 18, textDecoration: "line-through" }}>{fmt(product.oldPrice)}</span>
              <span style={{
                background: T.red, color: T.white, fontSize: 13,
                fontWeight: 700, borderRadius: 6, padding: "3px 8px",
              }}>Save {discount(product.price, product.oldPrice)}%</span>
            </div>

            {/* Qty + Add */}
            <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 16 }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 12,
                background: T.navyLt, borderRadius: 10, padding: "8px 14px",
                border: `1px solid ${T.navyMid}`,
              }}>
                <button onClick={() => setQty(q => Math.max(1, q - 1))} style={{
                  background: "none", border: "none", color: T.white,
                  fontSize: 20, cursor: "pointer", lineHeight: 1, padding: 0, width: 24,
                }}>−</button>
                <span style={{ color: T.white, fontWeight: 700, fontSize: 16, minWidth: 20, textAlign: "center" }}>{qty}</span>
                <button onClick={() => setQty(q => q + 1)} style={{
                  background: "none", border: "none", color: T.white,
                  fontSize: 20, cursor: "pointer", lineHeight: 1, padding: 0, width: 24,
                }}>+</button>
              </div>
              <button onClick={handleAdd} style={{
                flex: 1, padding: "14px",
                background: added ? T.green : T.cobalt,
                color: T.white, border: "none", borderRadius: 10,
                fontWeight: 800, fontSize: 16, cursor: "pointer",
                transition: "all 0.2s",
                boxShadow: `0 6px 24px ${added ? T.green : T.cobalt}44`,
              }}>{added ? "✓ Added to Cart!" : "Add to Cart"}</button>
            </div>

            {/* Trust badges */}
            <div style={{ display: "flex", gap: 20, marginTop: 24, flexWrap: "wrap" }}>
              {["🚚 Free Shipping", "↩ 30-Day Returns", "🔒 Secure Checkout"].map(b => (
                <span key={b} style={{ color: T.platDk, fontSize: 12, display: "flex", alignItems: "center", gap: 4 }}>{b}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div style={{ marginTop: 72 }}>
            <h3 style={{ color: T.white, fontSize: 22, fontWeight: 800, marginBottom: 24, letterSpacing: -0.5 }}>
              You Might Also Like
            </h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20 }}>
              {related.map(p => <ProductCard key={p.id} product={p} onAdd={(pr) => { for(let i=0;i<1;i++) onAdd(pr); }} onView={() => {}} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── CART DRAWER ─────────────────────────────────────────────────────────────
function CartDrawer({ open, onClose, cart, onRemove, onUpdateQty, onCheckout }) {
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <>
      {/* Overlay */}
      <div onClick={onClose} style={{
        position: "fixed", inset: 0, zIndex: 1100,
        background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)",
        opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none",
        transition: "opacity 0.3s",
      }} />
      {/* Drawer */}
      <div style={{
        position: "fixed", top: 0, right: 0, bottom: 0,
        width: "min(420px, 95vw)", zIndex: 1200,
        background: T.navyMid,
        borderLeft: `1px solid ${T.navyLt}`,
        transform: open ? "translateX(0)" : "translateX(100%)",
        transition: "transform 0.35s cubic-bezier(0.4,0,0.2,1)",
        display: "flex", flexDirection: "column",
        overflow: "hidden",
      }}>
        {/* Header */}
        <div style={{
          padding: "20px 24px",
          borderBottom: `1px solid ${T.navyLt}`,
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          <h2 style={{ color: T.white, margin: 0, fontSize: 20, fontWeight: 800 }}>
            Your Cart {cart.length > 0 && <span style={{ color: T.cobaltLt, fontSize: 15 }}>({cart.reduce((s,i)=>s+i.qty,0)})</span>}
          </h2>
          <button onClick={onClose} style={{
            background: T.navyLt, border: "none", color: T.platDk,
            width: 32, height: 32, borderRadius: 8, cursor: "pointer",
            fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center",
          }}>×</button>
        </div>

        {/* Items */}
        <div style={{ flex: 1, overflowY: "auto", padding: "16px 24px" }}>
          {cart.length === 0 ? (
            <div style={{ textAlign: "center", color: T.platDk, marginTop: 60 }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>🛒</div>
              <div style={{ fontSize: 16, fontWeight: 600 }}>Your cart is empty</div>
              <div style={{ fontSize: 13, marginTop: 8 }}>Add some products to get started</div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {cart.map(item => (
                <div key={item.id} style={{
                  display: "flex", gap: 14, alignItems: "center",
                  background: T.navyLt, borderRadius: 12, padding: 14,
                }}>
                  <div style={{
                    background: `linear-gradient(135deg, ${item.color}, ${T.navy})`,
                    borderRadius: 10, width: 56, height: 56, flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 28,
                  }}>{item.img}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ color: T.white, fontWeight: 700, fontSize: 13, marginBottom: 4, lineHeight: 1.3 }}>{item.name}</div>
                    <div style={{ color: T.cobaltLt, fontWeight: 800, fontSize: 15 }}>{fmt(item.price)}</div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
                    <div style={{
                      display: "flex", alignItems: "center", gap: 8,
                      background: T.navyMid, borderRadius: 8, padding: "4px 10px",
                    }}>
                      <button onClick={() => onUpdateQty(item.id, item.qty - 1)} style={{
                        background: "none", border: "none", color: T.platDk,
                        cursor: "pointer", fontSize: 16, padding: 0, lineHeight: 1,
                      }}>−</button>
                      <span style={{ color: T.white, fontSize: 14, fontWeight: 700, minWidth: 16, textAlign: "center" }}>{item.qty}</span>
                      <button onClick={() => onUpdateQty(item.id, item.qty + 1)} style={{
                        background: "none", border: "none", color: T.platDk,
                        cursor: "pointer", fontSize: 16, padding: 0, lineHeight: 1,
                      }}>+</button>
                    </div>
                    <button onClick={() => onRemove(item.id)} style={{
                      background: "none", border: "none", color: T.red,
                      cursor: "pointer", fontSize: 11, padding: 0,
                    }}>Remove</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div style={{ padding: "20px 24px", borderTop: `1px solid ${T.navyLt}` }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ color: T.platDk, fontSize: 14 }}>Subtotal</span>
              <span style={{ color: T.white, fontWeight: 700, fontSize: 16 }}>{fmt(total)}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
              <span style={{ color: T.platDk, fontSize: 14 }}>Shipping</span>
              <span style={{ color: T.green, fontWeight: 600, fontSize: 14 }}>Free</span>
            </div>
            <div style={{ borderTop: `1px solid ${T.navyLt}`, paddingTop: 16, marginBottom: 16, display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: T.white, fontWeight: 800, fontSize: 16 }}>Total</span>
              <span style={{ color: T.white, fontWeight: 900, fontSize: 22 }}>{fmt(total)}</span>
            </div>
            <button onClick={() => { onClose(); onCheckout(); }} style={{
              width: "100%", padding: "15px",
              background: `linear-gradient(135deg, ${T.cobalt}, ${T.cobaltLt})`,
              color: T.white, border: "none", borderRadius: 12,
              fontWeight: 800, fontSize: 16, cursor: "pointer",
              boxShadow: `0 8px 24px ${T.cobalt}44`,
            }}>Checkout → {fmt(total)}</button>
          </div>
        )}
      </div>
    </>
  );
}

// ─── CHECKOUT PAGE ───────────────────────────────────────────────────────────
function CheckoutPage({ cart, onBack, onComplete }) {
  const [step, setStep] = useState(1); // 1=info, 2=payment, 3=success
  const [form, setForm] = useState({ name:"", email:"", address:"", city:"", card:"", expiry:"", cvv:"" });
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const inputStyle = (focused) => ({
    width: "100%", background: T.navyLt, border: `1px solid ${focused ? T.cobalt : T.navyMid}`,
    color: T.white, borderRadius: 10, padding: "12px 14px", fontSize: 14,
    outline: "none", boxSizing: "border-box", transition: "border 0.2s",
  });

  if (step === 3) return (
    <div style={{
      minHeight: "100vh", background: T.navy,
      display: "flex", flexDirection: "column", alignItems: "center",
      justifyContent: "center", textAlign: "center", padding: "5%",
    }}>
      <div style={{ fontSize: 80, marginBottom: 24 }}>🎉</div>
      <h2 style={{ color: T.white, fontSize: 36, fontWeight: 900, margin: "0 0 12px", letterSpacing: -1 }}>Order Confirmed!</h2>
      <p style={{ color: T.platDk, fontSize: 18, marginBottom: 32 }}>
        Thank you, {form.name || "valued customer"}! Your order of <strong style={{ color: T.white }}>{fmt(total)}</strong> is on its way.
      </p>
      <div style={{ background: T.navyLt, borderRadius: 14, padding: "24px 36px", marginBottom: 36, border: `1px solid ${T.navyMid}` }}>
        <div style={{ color: T.platDk, fontSize: 13, marginBottom: 8 }}>Order confirmation sent to</div>
        <div style={{ color: T.cobaltLt, fontWeight: 700, fontSize: 16 }}>{form.email || "your email"}</div>
      </div>
      <button onClick={onComplete} style={{
        background: T.cobalt, color: T.white, border: "none", borderRadius: 12,
        padding: "14px 40px", fontSize: 16, fontWeight: 700, cursor: "pointer",
      }}>Continue Shopping</button>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: T.navy, padding: "100px 5% 80px" }}>
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <button onClick={onBack} style={{
          background: "none", border: "none", color: T.platDk,
          fontSize: 14, cursor: "pointer", marginBottom: 32,
          display: "flex", alignItems: "center", gap: 6, padding: 0,
        }}>← Back to Cart</button>

        <h2 style={{ color: T.white, fontSize: 32, fontWeight: 900, margin: "0 0 32px", letterSpacing: -1 }}>Checkout</h2>

        {/* Steps */}
        <div style={{ display: "flex", gap: 0, marginBottom: 40, alignItems: "center" }}>
          {["Shipping Info", "Payment", "Confirm"].map((s, i) => (
            <div key={s} style={{ display: "flex", alignItems: "center", flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{
                  width: 30, height: 30, borderRadius: "50%", flexShrink: 0,
                  background: i + 1 <= step ? T.cobalt : T.navyLt,
                  color: T.white, fontSize: 13, fontWeight: 800,
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>{i + 1 < step ? "✓" : i + 1}</div>
                <span style={{ color: i + 1 === step ? T.white : T.platDk, fontSize: 13, fontWeight: 600 }}>{s}</span>
              </div>
              {i < 2 && <div style={{ flex: 1, height: 1, background: T.navyLt, margin: "0 12px" }} />}
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 32 }}>
          {/* Form */}
          <div>
            {step === 1 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <h3 style={{ color: T.white, fontWeight: 800, fontSize: 18, margin: "0 0 8px" }}>Shipping Information</h3>
                {[
                  { k: "name",    label: "Full Name",       ph: "Jane Smith" },
                  { k: "email",   label: "Email Address",   ph: "jane@email.com" },
                  { k: "address", label: "Street Address",  ph: "123 Main Street" },
                  { k: "city",    label: "City & Postcode", ph: "New York, NY 10001" },
                ].map(({ k, label, ph }) => (
                  <div key={k}>
                    <label style={{ color: T.platDk, fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 6 }}>{label}</label>
                    <InputField val={form[k]} set={v => set(k, v)} ph={ph} />
                  </div>
                ))}
                <button onClick={() => setStep(2)} style={{
                  marginTop: 8, padding: "14px", background: T.cobalt,
                  color: T.white, border: "none", borderRadius: 12,
                  fontWeight: 800, fontSize: 15, cursor: "pointer",
                  boxShadow: `0 6px 20px ${T.cobalt}44`,
                }}>Continue to Payment →</button>
              </div>
            )}
            {step === 2 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <h3 style={{ color: T.white, fontWeight: 800, fontSize: 18, margin: "0 0 8px" }}>Payment Details</h3>
                <div style={{
                  background: T.navyLt, borderRadius: 12, padding: "16px",
                  border: `1px solid ${T.navyMid}`, display: "flex", gap: 10, alignItems: "center",
                  marginBottom: 8,
                }}>
                  {["💳 Visa","MC","Amex","PayPal"].map(m => (
                    <span key={m} style={{ background: T.navyMid, borderRadius: 6, padding: "4px 10px", color: T.platDk, fontSize: 12 }}>{m}</span>
                  ))}
                </div>
                {[
                  { k: "card",   label: "Card Number",   ph: "4242 4242 4242 4242" },
                  { k: "expiry", label: "Expiry Date",   ph: "MM / YY" },
                  { k: "cvv",    label: "CVV",            ph: "123" },
                ].map(({ k, label, ph }) => (
                  <div key={k}>
                    <label style={{ color: T.platDk, fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 6 }}>{label}</label>
                    <InputField val={form[k]} set={v => set(k, v)} ph={ph} />
                  </div>
                ))}
                <div style={{ display: "flex", gap: 12 }}>
                  <button onClick={() => setStep(1)} style={{
                    flex: "0 0 auto", padding: "14px 20px",
                    background: T.navyLt, color: T.platDk,
                    border: `1px solid ${T.navyMid}`, borderRadius: 12,
                    fontWeight: 700, cursor: "pointer",
                  }}>← Back</button>
                  <button onClick={() => setStep(3)} style={{
                    flex: 1, padding: "14px",
                    background: `linear-gradient(135deg, ${T.cobalt}, ${T.cobaltLt})`,
                    color: T.white, border: "none", borderRadius: 12,
                    fontWeight: 800, fontSize: 15, cursor: "pointer",
                  }}>Place Order → {fmt(total)}</button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div style={{ background: T.navyMid, borderRadius: 16, padding: 24, border: `1px solid ${T.navyLt}`, alignSelf: "start" }}>
            <h3 style={{ color: T.white, fontWeight: 800, fontSize: 16, margin: "0 0 20px" }}>Order Summary</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
              {cart.map(i => (
                <div key={i.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <span style={{ fontSize: 22 }}>{i.img}</span>
                    <div>
                      <div style={{ color: T.white, fontSize: 12, fontWeight: 600, lineHeight: 1.3 }}>{i.name}</div>
                      <div style={{ color: T.platDk, fontSize: 11 }}>×{i.qty}</div>
                    </div>
                  </div>
                  <span style={{ color: T.white, fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{fmt(i.price * i.qty)}</span>
                </div>
              ))}
            </div>
            <div style={{ borderTop: `1px solid ${T.navyLt}`, paddingTop: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ color: T.platDk, fontSize: 13 }}>Subtotal</span>
                <span style={{ color: T.white, fontWeight: 600 }}>{fmt(total)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <span style={{ color: T.platDk, fontSize: 13 }}>Shipping</span>
                <span style={{ color: T.green, fontSize: 13, fontWeight: 600 }}>Free</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: T.white, fontWeight: 800 }}>Total</span>
                <span style={{ color: T.cobaltLt, fontWeight: 900, fontSize: 20 }}>{fmt(total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InputField({ val, set, ph }) {
  const [focused, setFocused] = useState(false);
  return (
    <input
      value={val} onChange={e => set(e.target.value)} placeholder={ph}
      onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
      style={{
        width: "100%", background: T.navyLt, border: `1px solid ${focused ? T.cobalt : T.navyMid}`,
        color: T.white, borderRadius: 10, padding: "12px 14px", fontSize: 14,
        outline: "none", boxSizing: "border-box", transition: "border 0.2s",
      }}
    />
  );
}

// ─── FOOTER ──────────────────────────────────────────────────────────────────
function Footer() {
  const cols = [
    { title: "Shop", links: ["Electronics","Fashion","Home & Living","Beauty","New Arrivals","Sale"] },
    { title: "Company", links: ["About Us","Careers","Press","Sustainability","Investors"] },
    { title: "Support", links: ["Help Center","Returns","Track Order","Contact Us","Warranty"] },
  ];
  return (
    <footer style={{ background: T.navyMid, borderTop: `1px solid ${T.navyLt}`, padding: "60px 5% 32px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 48, marginBottom: 48 }}>
          <div>
            <div style={{ fontWeight: 900, fontSize: 24, letterSpacing: -1, marginBottom: 16 }}>
              <span style={{
                background: `linear-gradient(135deg, ${T.cobalt}, ${T.gold})`,
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              }}>NEXUS</span>
              <span style={{ color: T.platDk, fontWeight: 300, fontSize: 12, letterSpacing: 2, marginLeft: 6 }}>STORE</span>
            </div>
            <p style={{ color: T.platDk, fontSize: 14, lineHeight: 1.7, maxWidth: 280 }}>
              A curated marketplace for electronics, fashion, home goods, and beauty. Quality products, delivered fast.
            </p>
            <div style={{ display: "flex", gap: 12, marginTop: 20 }}>
              {["𝕏","in","ig","yt"].map(s => (
                <div key={s} style={{
                  width: 36, height: 36, borderRadius: 8,
                  background: T.navyLt, border: `1px solid ${T.navyMid}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: T.platDk, fontSize: 13, cursor: "pointer",
                  transition: "all 0.2s",
                }}>{s}</div>
              ))}
            </div>
          </div>
          {cols.map(col => (
            <div key={col.title}>
              <div style={{ color: T.white, fontWeight: 700, fontSize: 14, marginBottom: 18, letterSpacing: 0.5 }}>{col.title}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {col.links.map(l => (
                  <span key={l} style={{ color: T.platDk, fontSize: 13, cursor: "pointer", transition: "color 0.2s" }}
                    onMouseEnter={e => e.target.style.color = T.white}
                    onMouseLeave={e => e.target.style.color = T.platDk}
                  >{l}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ borderTop: `1px solid ${T.navyLt}`, paddingTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <span style={{ color: T.platDk, fontSize: 13 }}>© 2025 NEXUS Store. All rights reserved.</span>
          <div style={{ display: "flex", gap: 24 }}>
            {["Privacy","Terms","Cookies"].map(l => (
              <span key={l} style={{ color: T.platDk, fontSize: 13, cursor: "pointer" }}>{l}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage]           = useState("home"); // home | shop | product | checkout
  const [cart, setCart]           = useState([]);
  const [cartOpen, setCartOpen]   = useState(false);
  const [selected, setSelected]   = useState(null);
  const [initCat, setInitCat]     = useState("all");
  const [searchQ, setSearchQ]     = useState("");
  const [notif, setNotif]         = useState({ show: false, msg: "" });

  const showNotif = (msg) => {
    setNotif({ show: true, msg });
    setTimeout(() => setNotif(n => ({ ...n, show: false })), 2500);
  };

  const addToCart = (product) => {
    setCart(c => {
      const ex = c.find(i => i.id === product.id);
      if (ex) return c.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      return [...c, { ...product, qty: 1 }];
    });
    showNotif(`${product.name} added to cart`);
  };

  const removeFromCart = (id) => setCart(c => c.filter(i => i.id !== id));
  const updateQty = (id, qty) => {
    if (qty <= 0) return removeFromCart(id);
    setCart(c => c.map(i => i.id === id ? { ...i, qty } : i));
  };

  const onShop = (cat) => {
    setInitCat(cat);
    setPage("shop");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const onViewProduct = (product) => {
    setSelected(product);
    setPage("product");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const onHome = () => {
    setPage("home");
    setSearchQ("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSearch = (q) => {
    setSearchQ(q);
    if (q && page === "home") setPage("shop");
  };

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  return (
    <div style={{ fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif", background: T.navy, minHeight: "100vh" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: none; } }
        @keyframes bounce { 0%,100% { transform: translateX(-50%) translateY(0); } 50% { transform: translateX(-50%) translateY(6px); } }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${T.navyMid}; }
        ::-webkit-scrollbar-thumb { background: ${T.navyLt}; border-radius: 3px; }
        input::placeholder { color: ${T.platDk}88; }
        select option { background: ${T.navyMid}; }
      `}</style>

      <Navbar
        cartCount={cartCount}
        onCartOpen={() => setCartOpen(true)}
        onHome={onHome}
        page={page}
        onSearch={handleSearch}
        searchQ={searchQ}
      />

      {page === "home" && (
        <>
          <Hero onShop={onShop} />
          {/* Featured on home */}
          <section style={{ background: T.navyMid, padding: "80px 5%" }}>
            <div style={{ maxWidth: 1280, margin: "0 auto" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 32 }}>
                <div>
                  <div style={{ color: T.cobaltLt, fontSize: 12, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>— Featured</div>
                  <h2 style={{ color: T.white, fontSize: 32, fontWeight: 900, letterSpacing: -1 }}>Best Sellers This Week</h2>
                </div>
                <button onClick={() => onShop("all")} style={{
                  background: "none", border: `1px solid ${T.navyLt}`,
                  color: T.platDk, borderRadius: 10, padding: "10px 20px",
                  fontSize: 13, fontWeight: 600, cursor: "pointer",
                }}>View All →</button>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: 20 }}>
                {PRODUCTS.filter(p => p.badge === "Best Seller" || p.badge === "Top Rated").slice(0, 4).map(p => (
                  <ProductCard key={p.id} product={p} onAdd={addToCart} onView={onViewProduct} />
                ))}
              </div>
            </div>
          </section>
          {/* Categories strip */}
          <section style={{ background: T.navy, padding: "80px 5%" }}>
            <div style={{ maxWidth: 1280, margin: "0 auto" }}>
              <div style={{ color: T.cobaltLt, fontSize: 12, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>— Shop by Category</div>
              <h2 style={{ color: T.white, fontSize: 32, fontWeight: 900, letterSpacing: -1, marginBottom: 32 }}>Explore Collections</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                {CATEGORIES.filter(c => c.id !== "all").map(cat => (
                  <div key={cat.id} onClick={() => onShop(cat.id)} style={{
                    background: T.navyMid, border: `1px solid ${T.navyLt}`,
                    borderRadius: 16, padding: "32px 20px", textAlign: "center",
                    cursor: "pointer", transition: "all 0.25s",
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = T.navyLt; e.currentTarget.style.borderColor = T.cobalt + "55"; e.currentTarget.style.transform = "translateY(-4px)"; }}
                  onMouseLeave={e => { e.currentTarget.style.background = T.navyMid; e.currentTarget.style.borderColor = T.navyLt; e.currentTarget.style.transform = "none"; }}
                  >
                    <div style={{ fontSize: 42, marginBottom: 12 }}>{cat.icon}</div>
                    <div style={{ color: T.white, fontWeight: 800, fontSize: 16 }}>{cat.label}</div>
                    <div style={{ color: T.platDk, fontSize: 12, marginTop: 4 }}>
                      {PRODUCTS.filter(p => p.cat === cat.id).length} products
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
          <Footer />
        </>
      )}

      {page === "shop" && (
        <>
          <ShopPage initCat={initCat} onAdd={addToCart} onView={onViewProduct} searchQ={searchQ} />
          <Footer />
        </>
      )}

      {page === "product" && selected && (
        <>
          <ProductDetail
            product={selected}
            onAdd={addToCart}
            onBack={() => { setPage("shop"); window.scrollTo({ top: 0 }); }}
          />
          <Footer />
        </>
      )}

      {page === "checkout" && (
        <CheckoutPage
          cart={cart}
          onBack={() => { setPage("home"); setCartOpen(true); }}
          onComplete={() => { setCart([]); setPage("home"); }}
        />
      )}

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onRemove={removeFromCart}
        onUpdateQty={updateQty}
        onCheckout={() => setPage("checkout")}
      />

      <Notification show={notif.show} msg={notif.msg} />
    </div>
  );
}
