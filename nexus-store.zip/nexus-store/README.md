# 🛒 NEXUS Store

**A production-ready multi-product e-commerce platform built with React + Vite.**

![NEXUS Store](https://img.shields.io/badge/React-18.3-61DAFB?logo=react&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-5.4-646CFF?logo=vite&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)
![Deploy](https://img.shields.io/badge/Deploy-Vercel%20%7C%20GitHub%20Pages-black)

---

## ✨ Features

- **6 fully navigable layers** — Hero, Shop, Product Detail, Cart, Checkout, Confirmation
- **16 products across 4 categories** — Electronics, Fashion, Home & Living, Beauty
- **Live search & filtering** with category tabs and sort controls
- **Cart system** — persistent state, quantity controls, slide-in drawer
- **3-step checkout flow** — Shipping → Payment → Order Confirmation
- **Animated hero** with auto-cycling slides per product category
- **Responsive design** — works across desktop, tablet, and mobile
- **Frosted glass navbar** that transitions on scroll
- **Toast notifications** for cart actions
- **SEO-ready** with Open Graph and Twitter meta tags
- **Loading splash screen** with animated progress bar

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm 9+

### Local Development

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/nexus-store.git
cd nexus-store

# 2. Install dependencies
npm install

# 3. Start dev server (opens at http://localhost:3000)
npm run dev
```

### Production Build

```bash
npm run build       # outputs to /dist
npm run preview     # preview the production build locally
```

---

## 🌐 Deployment

### Option A — Vercel (Recommended, fastest)

#### One-click deploy:
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/nexus-store)

#### Manual Vercel deploy:
```bash
npm install -g vercel
vercel login
vercel --prod
```

#### CI/CD via GitHub Actions + Vercel:

1. Go to [vercel.com](https://vercel.com) → **Settings → Tokens** → create a token
2. In your GitHub repo → **Settings → Secrets → Actions**, add:

| Secret | Value |
|--------|-------|
| `VERCEL_TOKEN` | Your Vercel API token |
| `VERCEL_ORG_ID` | Found in Vercel project settings |
| `VERCEL_PROJECT_ID` | Found in Vercel project settings |

3. Push to `main` — GitHub Actions auto-deploys.

---

### Option B — GitHub Pages

1. In your repo → **Settings → Pages → Source** → select **GitHub Actions**
2. Push to `main` — the workflow deploys automatically to `https://YOUR_USERNAME.github.io/nexus-store`

> **Note:** For GitHub Pages, update `vite.config.js` to set the base path:
> ```js
> export default defineConfig({
>   base: '/nexus-store/',  // your repo name
>   plugins: [react()],
> })
> ```

---

### Option C — Netlify

```bash
npm install -g netlify-cli
netlify login
npm run build
netlify deploy --prod --dir=dist
```

Add a `_redirects` file to `/public`:
```
/*  /index.html  200
```

---

## 📁 Project Structure

```
nexus-store/
├── .github/
│   └── workflows/
│       └── deploy.yml          # CI/CD pipeline (Vercel + GitHub Pages)
├── public/
│   ├── favicon.svg
│   └── robots.txt
├── src/
│   ├── App.jsx                 # Full application (all components)
│   └── main.jsx                # React entry point
├── index.html                  # HTML shell with splash screen
├── vite.config.js              # Vite configuration
├── vercel.json                 # Vercel routing + cache headers
├── package.json
├── .eslintrc.cjs
└── .gitignore
```

---

## 🎨 Customisation

### Design Tokens
All colours live in the `T` object at the top of `src/App.jsx`:

```js
const T = {
  navy:    "#0A0F1E",   // page background
  cobalt:  "#2563EB",   // primary accent (buttons, links)
  gold:    "#F59E0B",   // secondary accent (badges, highlights)
  ...
}
```

### Adding Products
Add objects to the `PRODUCTS` array in `src/App.jsx`:

```js
{
  id: 17,
  name: "My New Product",
  cat: "electronics",           // electronics | fashion | home | beauty
  price: 99,
  oldPrice: 129,
  rating: 4.5,
  reviews: 500,
  badge: "New",                 // Best Seller | New | Top Rated | Trending | Eco | Luxury | ""
  color: "#1E2640",             // card background gradient start
  img: "📱",                    // emoji displayed as product image
  desc: "Product description here."
}
```

### Adding Categories
Add to the `CATEGORIES` array and use the new `id` as a `cat` value in products.

---

## 🔒 Security Headers

Configured in `vercel.json`:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `X-XSS-Protection: 1; mode=block`
- `Referrer-Policy: strict-origin-when-cross-origin`
- Long-term caching for static assets

---

## 📦 Tech Stack

| Tool | Version | Purpose |
|------|---------|---------|
| React | 18.3 | UI library |
| Vite | 5.4 | Build tool & dev server |
| GitHub Actions | — | CI/CD pipeline |
| Vercel | — | Production hosting |

---

## 🗺️ Roadmap

- [ ] Stripe payment integration
- [ ] Supabase backend for real product data
- [ ] User authentication (Supabase Auth)
- [ ] Wishlist / favourites
- [ ] Product image uploads
- [ ] Admin dashboard
- [ ] PWA support

---

## 📄 License

MIT © NEXUS Store
